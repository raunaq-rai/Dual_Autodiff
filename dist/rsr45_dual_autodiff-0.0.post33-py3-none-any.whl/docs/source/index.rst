.. dual_autodiff documentation master file, created by
   sphinx-quickstart on Thu Nov 21 10:31:35 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

dual_autodiff documentation
===========================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   tutorial
   dual_autodiff
   modules
   apple_silicon_x86_setup
