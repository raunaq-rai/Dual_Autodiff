dual\_autodiff package
======================

Submodules
----------

dual\_autodiff.base module
--------------------------

.. automodule:: dual_autodiff.base
   :members:
   :undoc-members:
   :show-inheritance:

dual\_autodiff.dual module
--------------------------

.. automodule:: dual_autodiff.dual
   :members:
   :undoc-members:
   :show-inheritance:

dual\_autodiff.functions module
-------------------------------

.. automodule:: dual_autodiff.functions
   :members:
   :undoc-members:
   :show-inheritance:

dual\_autodiff.version module
-----------------------------

.. automodule:: dual_autodiff.version
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dual_autodiff
   :members:
   :undoc-members:
   :show-inheritance:
